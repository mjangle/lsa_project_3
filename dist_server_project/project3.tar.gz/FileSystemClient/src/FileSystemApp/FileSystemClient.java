package FileSystemApp;

import org.omg.CosNaming.*;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;

import org.omg.CORBA.*;

/**
 * A simple client that just gets a
 * @author Merlin
 *
 */
public class FileSystemClient
{
	static FileSystem fileSystemImpl;
	private static long startTime; 
	private static long endTime;
	private static long duration;
	private static String durationString;

	/**
	 * Just do each operation once
	 * @param args ignored
	 */
	public static void main(String args[])
	{
		try
		{
			// create and initialize the ORB
			ORB orb = ORB.init(args, null);

			// get the root naming context
			org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");
			// Use NamingContextExt instead of NamingContext. This is
			// part of the Interoperable naming Service.
			NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);

			// resolve the Object Reference in Naming
			String name = "FileSystem";
			fileSystemImpl = FileSystemHelper.narrow(ncRef.resolve_str(name));

			System.out.println("Obtained a handle on server object: " + fileSystemImpl);
			// System.out.println(fileSystemImpl.sayHello());
			// System.out.println("finished hello starting to read file");
			for (int i =0; i<1000; i++) {
			startTime = System.currentTimeMillis();
			String fileOBJ = fileSystemImpl.readFile("test2.txt");
			endTime = System.currentTimeMillis();
			try {
				FileWriter writer = new FileWriter("receivedFile.txt");
				writer.write(fileOBJ);
				writer.close();
				System.out.println("File Received");
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			duration = (endTime - startTime);
			durationString = String.valueOf(duration);
			Date date = new Date();
			try {
				FileWriter results = new FileWriter("javaReslutsSpain03.csv",true);
				results.append(date.toString()+ "," + durationString + "\n");
				results.close();
				System.out.println("Results Captured #:" + i);
			} catch (IOException e) {
				e.printStackTrace();
			}
			}
			
			// This is how we would shut down the server
			//fileSystemImpl.shutdown();

		} catch (Exception e)
		{
			System.out.println("ERROR : " + e);
			e.printStackTrace(System.out);
		}
	
}
}
